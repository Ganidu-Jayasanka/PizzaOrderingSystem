package PizzaOrderingSystem;


public class Main {
	
	public static void main(String[] args)
	{
    // Create an instance of the UserInterface class
	UserInterface UI = new UserInterface();
	
	// Start the application by invoking the start method of the UserInterface
	UI.start();
	
}
}